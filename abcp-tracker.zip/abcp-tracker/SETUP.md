# ABCP Tracker — Setup Guide
## Built for: 5'7" / 230 lbs / Male / Age 28 | AR 600-9 2026

---

## STEP 1 — Create Your Whoop Developer App

1. Go to https://developer.whoop.com
2. Sign in with your regular Whoop account
3. Click "Create App"
4. Fill in:
   - App Name: ABCP Tracker
   - Redirect URI: https://abcp-tracker-backend.up.railway.app/api/auth/callback
     (you'll update this once Railway gives you a URL)
   - Scopes: read:recovery, read:sleep, read:workout, read:body_measurement, read:cycles, offline
5. Save — copy your CLIENT ID and CLIENT SECRET somewhere safe

---

## STEP 2 — Create Your Supabase Database (free)

1. Go to https://supabase.com and sign up (free)
2. Create a new project — name it "abcp-tracker"
3. Wait for it to spin up (~1 min)
4. Go to SQL Editor (left sidebar)
5. Paste the entire contents of backend/schema.sql and click Run
6. Go to Settings → API
7. Copy:
   - Project URL → this is your SUPABASE_URL
   - service_role key (under "Project API Keys") → this is your SUPABASE_SERVICE_KEY

---

## STEP 3 — Deploy the Backend to Railway (free)

1. Go to https://railway.app and sign up with GitHub
2. Click "New Project" → "Deploy from GitHub repo"
3. Upload or connect this project folder
4. Railway will detect it and ask for env variables
5. Add these environment variables:

   WHOOP_CLIENT_ID          = (from Step 1)
   WHOOP_CLIENT_SECRET      = (from Step 1)
   WHOOP_REDIRECT_URI       = https://YOUR-RAILWAY-URL/api/auth/callback
   SUPABASE_URL             = (from Step 2)
   SUPABASE_SERVICE_KEY     = (from Step 2)
   JWT_SECRET               = (type any long random string, e.g. "abcp2026secretkey123xyz")
   FRONTEND_URL             = https://abcp-tracker.vercel.app
   PORT                     = 3001

6. Railway gives you a URL like: https://abcp-tracker-backend.up.railway.app
7. Go BACK to Whoop developer portal and update your Redirect URI to:
   https://abcp-tracker-backend.up.railway.app/api/auth/callback

---

## STEP 4 — Deploy the Frontend to Vercel (free)

1. Go to https://vercel.com and sign up with GitHub
2. Click "Add New Project"
3. Upload the /frontend folder
4. Add this environment variable:
   VITE_API_URL = https://abcp-tracker-backend.up.railway.app
5. Deploy — Vercel gives you a URL like: https://abcp-tracker.vercel.app
6. Go BACK to Railway and update FRONTEND_URL to your actual Vercel URL

---

## STEP 5 — Test It

1. Open your Vercel URL on your phone
2. Tap "Connect Whoop"
3. Log in with your Whoop credentials
4. You should see your recovery score, HRV, and calories pulled live

---

## What Each Feature Does

| Feature | Source |
|---|---|
| Recovery Score | Whoop API — pulled daily |
| HRV / Resting HR | Whoop API |
| Sleep Performance | Whoop API |
| Calories Burned | Whoop API (real number, not estimate) |
| Cortisol Warning | Triggers when sleep < 60% |
| Workout Adjustment | Auto-scales based on recovery % |
| Food Log | You log manually (preset meals from your plan) |
| Real Deficit | Whoop calories - your food log |
| Waist / Weight Log | You log weekly |
| Tape Test Predictor | Calculates from your waist trend rate |
| ABCP Readiness Score | Combines all of the above into 0-100 |

---

## Your Key Numbers (hardcoded to your profile)

- Height: 5'7" (67 inches)
- Start weight: 230 lbs
- Target weight: 210 lbs
- Waist goal: under 36.5" (WHtR pass at 5'7")
- Max body fat: 24% (age 28-39 male)
- Daily calorie target: 1,530 cal eaten
- Daily deficit target: 1,750 cal
- Timeline: 8 weeks
